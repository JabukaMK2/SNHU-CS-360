package com.example.projecttwo;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.List;

// Adapter class for the inventory grid view
public class InventoryAdapter extends ArrayAdapter<Inventory> {

    private OnDeleteClickListener onDeleteClickListener;

    // Interface for the delete button click listener
    public interface OnDeleteClickListener {
        void onDeleteClick(Inventory inventory);
    }

    // Constructor
    public InventoryAdapter(@NonNull Context context, @NonNull List<Inventory> inventoryList) {
        super(context, 0, inventoryList);
    }

    // Setter for the delete button click listener
    public void setOnDeleteClickListener(OnDeleteClickListener listener) {
        this.onDeleteClickListener = listener;
    }

    // getView method to customize the list item layout
    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {

        // Inflate the layout for each list item
        if (convertView == null) {
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.grid_item, parent, false);
        }

        // Get the current item from the adapter
        Inventory currentItem = getItem(position);

        // Find the views in the list item layout
        TextView itemName = convertView.findViewById(R.id.item_text);
        TextView itemSku = convertView.findViewById(R.id.sku_text);
        TextView itemOnHand = convertView.findViewById(R.id.on_hand_label);
        Button deleteButton = convertView.findViewById(R.id.delete_button);

        // Set the text and click listener for the delete button
        if (currentItem != null) {
            itemName.setText(currentItem.getItemName());
            itemSku.setText("SKU: " + currentItem.getSku());
            itemOnHand.setText("On-Hand: " + currentItem.getCount());

            // Set the click listener for the delete button
            deleteButton.setOnClickListener(v -> {
                if (onDeleteClickListener != null) {
                    onDeleteClickListener.onDeleteClick(currentItem);
                }
            });
        }

        // Return the updated view
        return convertView;
    }
}

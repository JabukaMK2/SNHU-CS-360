package com.example.projecttwo;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.navigation.fragment.NavHostFragment;

// Fragment for adding a new item to the inventory
public class ThirdFragment extends Fragment {

    private InventoryDatabase inventoryDatabase;
    private EditText editName;
    private EditText editSKU;
    private EditText editOnHand;

    // When the view is created, initialize the database
    @Override
    public View onCreateView(
            @NonNull LayoutInflater inflater, ViewGroup container,
            Bundle savedInstanceState
    ) {

        // Inflate the layout for this fragment
        inventoryDatabase = new InventoryDatabase(requireContext());
        return inflater.inflate(R.layout.fragment_third, container, false);
    }

    // When the view is created, set up the button click listener
    @Override
    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        // Find the views in the layout
        editName = view.findViewById(R.id.editName);
        editSKU = view.findViewById(R.id.editSKU);
        editOnHand = view.findViewById(R.id.editOnHand);
        Button buttonAddItem = view.findViewById(R.id.buttonAddItem);

        // Set up the button click listener
        buttonAddItem.setOnClickListener(v -> addNewItem());
    }

    // Add a new item to the database
    public void addNewItem() {
        String name = editName.getText().toString();
        String skuString = editSKU.getText().toString();
        String onHandString = editOnHand.getText().toString();

        // Check if all fields are filled
        if (name.isEmpty() || skuString.isEmpty() || onHandString.isEmpty()) {
            Toast.makeText(requireContext(), "Please fill all fields", Toast.LENGTH_SHORT).show();
            return;
        }

        // Check if SKU and On-Hand are valid numbers
        try {
            double sku = Double.parseDouble(skuString);
            int onHand = Integer.parseInt(onHandString);

            // Run database operation on a background thread to avoid blocking the UI
            new Thread(() -> {
                long newId = inventoryDatabase.addInventory(name, onHand, sku);
                requireActivity().runOnUiThread(() -> {

                    // Check if the item was added successfully
                    if (newId != -1) {
                        Toast.makeText(requireContext(), "Item added successfully!", Toast.LENGTH_SHORT).show();
                        NavHostFragment.findNavController(ThirdFragment.this)
                                .navigate(R.id.action_ThirdFragment_to_SecondFragment);
                    } else { // If the item was not added successfully, show an error message
                        Toast.makeText(requireContext(), "Error adding item.", Toast.LENGTH_SHORT).show();
                    }
                });
            }).start();
        } catch (NumberFormatException e) { // If SKU or On-Hand are not valid numbers, show an error message
            Toast.makeText(requireContext(), "Please enter valid numbers for SKU and On-Hand", Toast.LENGTH_SHORT).show();
        }
    }

    // When the view is destroyed, close the database connection
    @Override
    public void onDestroyView() {
        super.onDestroyView();
        inventoryDatabase.close(); // Close the database connection
    }
}

package com.example.projecttwo;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.GridView;
import android.widget.Switch;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.navigation.fragment.NavHostFragment;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.List;

// This fragment displays the list of inventory items and handles user interactions.
// It implements the OnDeleteClickListener to handle delete events from the adapter.
public class SecondFragment extends Fragment implements InventoryAdapter.OnDeleteClickListener {

    // Database helper for the Inventory table
    private InventoryDatabase inventoryDatabase;
    // The GridView that displays the inventory items
    private GridView itemsGrid;
    // The custom adapter that connects the data to the GridView
    private InventoryAdapter adapter;

    // ActivityResultLauncher to handle the SMS permission request
    private final ActivityResultLauncher<String> requestPermissionLauncher =
            registerForActivityResult(new ActivityResultContracts.RequestPermission(), isGranted -> {
                if (isGranted) {

                    // If permission is granted, show a confirmation toast
                    Toast.makeText(requireContext(), "SMS permission granted", Toast.LENGTH_SHORT).show();
                } else {

                    // If permission is denied, show a toast and uncheck the switch
                    Toast.makeText(requireContext(), "SMS permission denied", Toast.LENGTH_SHORT).show();

                    // Safely access the switch to uncheck it
                    Switch smsSwitch = getView() != null ? getView().findViewById(R.id.switchSMS) : null;
                    if (smsSwitch != null) {
                        smsSwitch.setChecked(false);
                    }
                }
            });

    @Override
    public View onCreateView(
            @NonNull LayoutInflater inflater, ViewGroup container,
            Bundle savedInstanceState
    ) {

        // Initialize the database helper
        inventoryDatabase = new InventoryDatabase(requireContext());

        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_second, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        // Get references to the UI elements from the layout
        itemsGrid = view.findViewById(R.id.items_grid);
        FloatingActionButton buttonAddItem = view.findViewById(R.id.buttonAddItem);

        // Initialize the SMS switch
        Switch switchSMS = view.findViewById(R.id.switchSMS);

        // Set a click listener for the "Add Item" button to navigate to the ThirdFragment
        buttonAddItem.setOnClickListener(v ->
                NavHostFragment.findNavController(SecondFragment.this)
                        .navigate(R.id.action_SecondFragment_to_ThirdFragment)
        );

        // Set a listener for the SMS switch to handle permission requests
        switchSMS.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (isChecked) {

                // If the switch is checked, verify if SMS permission has been granted
                if (ContextCompat.checkSelfPermission(
                        requireContext(), Manifest.permission.SEND_SMS) !=
                        PackageManager.PERMISSION_GRANTED) {

                    // If permission is not granted, launch the permission request
                    requestPermissionLauncher.launch(Manifest.permission.SEND_SMS);
                }
            }
        });

        // Load the inventory items from the database
        loadInventoryItems();
    }

    // Loads inventory items from the database and populates the GridView
    private void loadInventoryItems() {

        // Run the database query on a background thread to keep the UI responsive
        new Thread(() -> {
            List<Inventory> inventoryList = inventoryDatabase.getAllInventory();

            // Switch back to the UI thread to update the GridView
            requireActivity().runOnUiThread(() -> {

                // Create the adapter with the retrieved list
                adapter = new InventoryAdapter(requireContext(), inventoryList);

                // Set the delete click listener to this fragment
                adapter.setOnDeleteClickListener(this);

                // Set the adapter on the GridView
                itemsGrid.setAdapter(adapter);
            });
        }).start();
    }

    // This method is called from the InventoryAdapter when a delete button is clicked
    @Override
    public void onDeleteClick(Inventory inventory) {
        // Run the delete operation on a background thread
        new Thread(() -> {

            // Delete the item from the database
            inventoryDatabase.deleteInventory(inventory.getId());

            // Switch back to the UI thread to update the list
            requireActivity().runOnUiThread(() -> {

                // Remove the item from the adapter
                adapter.remove(inventory);

                // Notify the adapter that the data set has changed
                adapter.notifyDataSetChanged();

                // Show a confirmation toast
                Toast.makeText(requireContext(), "Item deleted", Toast.LENGTH_SHORT).show();
            });
        }).start();
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();

        // Close the database connection when the view is destroyed to prevent memory leaks
        inventoryDatabase.close();
    }
}

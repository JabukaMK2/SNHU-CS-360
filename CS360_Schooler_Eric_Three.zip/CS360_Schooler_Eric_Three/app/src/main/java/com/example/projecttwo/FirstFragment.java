package com.example.projecttwo;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.navigation.fragment.NavHostFragment;

// This fragment represents the first screen of the application
// It allows users to sign in or add a new user
public class FirstFragment extends Fragment {

    // Database helper for the User table
    private UserDatabase userDatabase;
    // UI elements for username and password input
    private EditText usernameEditText;
    private EditText passwordEditText;

    @Override
    public View onCreateView(
            @NonNull LayoutInflater inflater, ViewGroup container,
            Bundle savedInstanceState
    ) {

        // Initialize the database helper
        userDatabase = new UserDatabase(requireContext());

        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_first, container, false);
    }

    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        // Get references to the EditText fields and Buttons from the layout
        usernameEditText = view.findViewById(R.id.editTextUsername);
        passwordEditText = view.findViewById(R.id.editTextPassword);
        Button signInButton = view.findViewById(R.id.buttonSignIn);
        Button addUserButton = view.findViewById(R.id.buttonAddUser);

        // Set a click listener for the Sign In button
        signInButton.setOnClickListener(v -> {

            // Get the text from the input fields
            String username = usernameEditText.getText().toString();
            String password = passwordEditText.getText().toString();

            // Check if either field is empty
            if (username.isEmpty() || password.isEmpty()) {
                Toast.makeText(requireContext(), "Please enter username and password", Toast.LENGTH_SHORT).show();
                return; // Stop further execution
            }

            // Run the database check on a background thread to keep the UI responsive
            new Thread(() -> {

                // Check if the user exists in the database
                boolean isValid = userDatabase.checkUser(username, password);

                // Switch back to the UI thread to update the UI
                requireActivity().runOnUiThread(() -> {
                    if (isValid) {

                        // If credentials are valid, navigate to the second fragment
                        NavHostFragment.findNavController(FirstFragment.this)
                                .navigate(R.id.action_FirstFragment_to_SecondFragment);
                    } else {
                        // Otherwise, show an error message
                        Toast.makeText(requireContext(), "Invalid credentials", Toast.LENGTH_SHORT).show();
                    }
                });
            }).start();
        });

        // Set a click listener for the Add User button
        addUserButton.setOnClickListener(v -> {

            // Get the text from the input fields
            String username = usernameEditText.getText().toString();
            String password = passwordEditText.getText().toString();

            // Check if either field is empty
            if (username.isEmpty() || password.isEmpty()) {
                Toast.makeText(requireContext(), "Please enter username and password", Toast.LENGTH_SHORT).show();
                return; // Stop further execution
            }

            // Run the database insertion on a background thread
            new Thread(() -> {

                // Attempt to add the new user to the database
                long result = userDatabase.addUser(username, password);

                // Switch back to the UI thread to show the result
                requireActivity().runOnUiThread(() -> {

                    // The addUser method returns -1 if the username is already taken (due to UNIQUE constraint)
                    if (result != -1) {
                        Toast.makeText(requireContext(), "User added successfully", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(requireContext(), "Username already exists", Toast.LENGTH_SHORT).show();
                    }
                });
            }).start();
        });
    }

    // Override the onDestroyView method to close the database connection when the view is destroyed
    @Override
    public void onDestroyView() {
        super.onDestroyView();

        // Close the database connection when the view is destroyed to prevent memory leaks
        userDatabase.close();
    }
}

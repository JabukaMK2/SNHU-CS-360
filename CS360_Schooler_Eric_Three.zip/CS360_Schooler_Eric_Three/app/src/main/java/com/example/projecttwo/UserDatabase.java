package com.example.projecttwo;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

// Database class for user
public class UserDatabase extends SQLiteOpenHelper {
    public static final String DATABASE_NAME = "user.db";
    public static final int DATABASE_VERSION = 1;

    // Constructor
    public UserDatabase(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    private static final class UserTable {
        public static final String TABLE = "User";
        public static final String COLUMN_ID = "_id";
        public static final String COLUMN_USERNAME = "name";
        public static final String COLUMN_PASSWORD = "password";
    }

    // Create table
    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE " + UserTable.TABLE + " (" +
                UserTable.COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                UserTable.COLUMN_USERNAME + " TEXT NOT NULL UNIQUE, " +
                UserTable.COLUMN_PASSWORD + " TEXT NOT NULL);");
    }

    // Delete table when upgrade
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + UserTable.TABLE);
        onCreate(db);
    }

    // Add user
    public long addUser(String username, String password) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(UserTable.COLUMN_USERNAME, username);
        values.put(UserTable.COLUMN_PASSWORD, password);

        return db.insert(UserTable.TABLE, null, values);
    }

    // Check user exists in current database
    public boolean checkUser(String username, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(UserTable.TABLE,

                // Columns - null selects all columns
                new String[]{UserTable.COLUMN_ID},
                UserTable.COLUMN_USERNAME + " = ? AND " + UserTable.COLUMN_PASSWORD + " = ?",
                new String[]{username, password},
                null, null, null);

        // Check if user exists
        int count = cursor.getCount();
        cursor.close();
        return count > 0;
    }
}

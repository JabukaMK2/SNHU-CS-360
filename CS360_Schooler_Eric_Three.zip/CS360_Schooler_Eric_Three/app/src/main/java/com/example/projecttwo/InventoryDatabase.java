package com.example.projecttwo;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

// Inventory Database
public class InventoryDatabase extends SQLiteOpenHelper {
    public static final String DATABASE_NAME = "inventory.db";
    public static final int DATABASE_VERSION = 1;

    // Constructor
    public InventoryDatabase(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    private static final class InventoryTable {
        public static final String TABLE = "inventory";
        public static final String COLUMN_ID = "_id";
        public static final String COLUMN_NAME = "name";
        public static final String COLUMN_ONHAND = "onhand";
        public static final String COLUMN_SKU = "sku";
    }

    // Creates Inventory Database
    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE " + InventoryTable.TABLE + " (" +
                InventoryTable.COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                InventoryTable.COLUMN_NAME + " TEXT NOT NULL, " +
                InventoryTable.COLUMN_ONHAND + " INTEGER NOT NULL, " +
                InventoryTable.COLUMN_SKU + " REAL NOT NULL);");
    }

    // Updates Inventory Database upon upgrade
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + InventoryTable.TABLE);
        onCreate(db);
    }

    // Deletes Inventory Database
    public void deleteInventory(long id) {
        SQLiteDatabase db = this.getWritableDatabase();
        String query = "DELETE FROM " + InventoryTable.TABLE;
        db.execSQL(query);
    }

    // Adds Inventory to Database
    public long addInventory(String name, int onhand, double sku) {
        SQLiteDatabase db = this.getWritableDatabase();

        // Add inventory to database
        ContentValues values = new ContentValues();
        values.put(InventoryTable.COLUMN_NAME, name);
        values.put(InventoryTable.COLUMN_ONHAND, onhand);
        values.put(InventoryTable.COLUMN_SKU, sku);

        // Inserting Row
        long inventoryId = db.insert(InventoryTable.TABLE, null, values);
        return inventoryId;
    }

    // Getter for Inventory in database, converts to list for use in adapter
    public List<Inventory> getAllInventory() {

        // Create list of inventories
        List<Inventory> inventoryList = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.query(InventoryTable.TABLE, null, null, null, null, null, InventoryTable.COLUMN_NAME + " ASC");

        // Cache column indices for better performance
        int idColumn = cursor.getColumnIndexOrThrow(InventoryTable.COLUMN_ID);
        int nameColumn = cursor.getColumnIndexOrThrow(InventoryTable.COLUMN_NAME);
        int onHandColumn = cursor.getColumnIndexOrThrow(InventoryTable.COLUMN_ONHAND);
        int skuColumn = cursor.getColumnIndexOrThrow(InventoryTable.COLUMN_SKU);

        // Iterate through cursor
        while (cursor.moveToNext()) {
            long id = cursor.getLong(idColumn);
            String name = cursor.getString(nameColumn);
            int onHand = cursor.getInt(onHandColumn);
            double sku = cursor.getDouble(skuColumn);

            // Add inventory to list
            Inventory inventory = new Inventory();
            inventory.setId(id);
            inventory.setItemName(name);
            inventory.setCount(onHand);
            inventory.setSku(sku);

            inventoryList.add(inventory);
        }
        // Close cursor
        cursor.close();
        return inventoryList;
    }
}
